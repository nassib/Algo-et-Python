#coding=utf8

# Cherche une valeur dans une liste et détermine son rang
maListeDeNombres = [ 10, 20, -5, 1.3, 100, 9, 1, 72 ]
valeur = 9

rang = 0
n = len (maListeDeNombres)
while rang < n and valeur != maListeDeNombres[rang ] :
	rang = rang + 1

if rang < n :
	print( "La valeur %f existe au rang %d." %(valeur, rang))
else :
	print("La valeur n'a pas été trouvée !")