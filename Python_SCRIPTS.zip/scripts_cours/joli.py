# C'est beau !
for i in range(8) :
	print("   " * i, "Joli", "   " * (7-i) * 2, "Joli")
