print ("Calcul de PGCD")

a = int (input ("Entrez un nombre : "))
b = int (input ("Entrez un nombre : "))

while a != b :
	if a > b :
		a = a - b
	else :
		b = b - a

print ("Le PGCD est %d" %(a))
