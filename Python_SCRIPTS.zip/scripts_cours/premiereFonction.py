def proportion ( chaine, caractere ) :
	"""Fréquence d'appartion du caractere dans la chaine.

	chaine est une chaine de caractère non vide
	caractere est un caractere unique"""

	n = len( chaine )
	k = chaine.count( caractere )

	return k/n
