import premiereFonction

texte = "Bonjour à tous !"
nbO = premiereFonction.proportion( texte, 'o')
nbU = premiereFonction.proportion( texte, 'u')

print( "Texte : ", texte)
print( "Proportion de o : ", nbO)
print( "Proportion de u : ", nbU)
