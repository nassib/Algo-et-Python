# La valeur de la TVA est écrite dans la fonction
def calculPrixTTC (prixHT):
	return prixHT * 1.2

# La valeur de la TVA est passée à la fonction
def calculPrixTTC (prixHT, TVA):
	return prixHT * (1 + TVA / 100)

# TVA est une variable globale
TVA = 20
# La variable globale est utilisée dans la fonction
def calculPrixTTC (prixHT):
	return prixHT * (1 + TVA / 100)
