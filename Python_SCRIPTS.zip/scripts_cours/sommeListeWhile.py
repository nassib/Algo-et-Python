#coding=utf8

# Calcul de la somme des éléments d'une liste de nombres
maListeDeNombres = [ 10, 20, -5, 1.3, 100 ]

somme = 0
n = len (maListeDeNombres)
i = 0

while i < n :
	somme = somme + maListeDeNombres[i]
	i = i + 1

print( "La somme des éléments est : %f" %(somme))