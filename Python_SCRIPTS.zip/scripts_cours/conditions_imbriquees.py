# coding=utf8

embranchement = input ( "Embranchement ? ")
classe = input ( "Classe ? ")
ordre = input ( "Ordre ? ")
famille = input ( "Famille ? ")

if embranchement == "vertébrés":                 
    if classe == "mammifères":                   
        if ordre == "carnivores":                
            if famille == "félins":              
                print ( "C'est peut-être un chat" ) 
        print ( "C'est en tous cas un mammifère" )   
    elif classe == 'oiseaux':                    
        print ( "C'est peut-être un canari" )        
print ( "La classification des animaux est complexe." )