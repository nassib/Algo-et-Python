# coding=utf8

min = int ( input ( "Minimum ? " ))
max = int ( input ( "Maximum ? " ))
if min > max :
	print ( "Le minimum est plus grand que le maximum !!!" )
print ( "Fin du programme." )