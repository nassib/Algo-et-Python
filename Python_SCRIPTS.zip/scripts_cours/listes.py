# ATTENTION Ceci n'est pas vraiment un script
# C'est le fichier qui contient les lignes de démonstration de la partie
# Structure de données

# Une liste est simplement des valeurs séparées par des virgules, entre crochets.
# Les valeurs peuvent être de type différent.
a = [ 'riri', 'fifi', 10, 450, 100 ]
a

# Les listes sont indexées. Le premier index est 0.
a[ 0 ]
a[ 3 ]
a[ -2 ]

# Il est possible d'extarire des sous-listes, de concaténer des listes ...
# Ces opérations retournent des listes
a[ 1:-1 ]
a[ : 2 ] + [ 'loulou', 2*2 ]
3 * a[:3] + ['donald']

# Il est possible de modifier des sous-listes
a[0:2] = [ 3, 'fantastiques']
a
# Suppression d'éléments
a[0:2] = []
a
# Insertion
a[1:1] = ['super', 'bien']
a
# On ajoute la liste au début de la liste
a[:0] = a
a
# On efface la liste
a[:] = []
a

# Une liste peut contenir d'autres listes
l1 = [1, 2, 3]
l2 = [0, l1, 4, 5]
len(l1)
len(l2)
l1
l2
l2[1]
l2[1][0]



