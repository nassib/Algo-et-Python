nbAppels = 0

def maFonction():
	global nbAppels
	nbAppels = nbAppels + 1

for i in range(20):
	maFonction()

print ("La fonction a été appelée", nbAppels, "fois")