def afficherListeVerticale (maListe):
	i = 0
	for e in maListe:
		print (e)
		i = i + 1

l = ["un", "deux", "trois", "quatre"]
print (l)
afficherListeVerticale(l)