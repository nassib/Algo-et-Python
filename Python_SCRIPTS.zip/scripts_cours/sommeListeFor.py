#coding=utf8

# Calcul de la somme des éléments d'une liste de nombres
maListeDeNombres = [ 10, 20, -5, 1.3, 100 ]

somme = 0

for e in maListeDeNombres :
	somme = somme + e

print( "La somme des éléments est : %f" %(somme))