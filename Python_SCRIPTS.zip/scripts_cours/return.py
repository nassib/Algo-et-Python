# Recherche d'un élément d'une liste égal à une valeur donnée

def indice(valeur, liste):
	"""Renvoie l'indice du premier élément de la liste qui a la valeur indiquée ou -1 si l'élément n'est pas présent.
	"""

	for i in range(len(liste)):
		if valeur == liste[i]:
			return i
	return -1

l = [1, 2, 3, 4, 55, 66, 777, 888]
print (indice(4, l))
print (indice(777, l))