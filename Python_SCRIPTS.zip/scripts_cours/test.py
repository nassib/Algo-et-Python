# Mon premier test d'un script python
print ("Bonjour")
print (1+2)
