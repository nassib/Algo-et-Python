# coding=utf8

somme = 0
nombreTotal = 0
nombreGrands = 0

n = int ( input ( "n ? " ) )
while n > 0 :
	somme = somme + n
	nombreTotal = nombreTotal + 1
	if n > 100 :
		nombreGrands = nombreGrands +1
	n = int ( input ( "n ? " ) )

print ( "Somme : %d" %(somme))
print ( "Vous avez saisi %d nombre(s) dont %d nombre(s) plus grand(s) que 100." \
	 %(nombreTotal, nombreGrands))
