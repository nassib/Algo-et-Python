from premiereFonction import proportion

texte = "Bonjour à tous !"
nbO = proportion( texte, 'o')
nbU = proportion( texte, 'u')

print( "Texte : ", texte)
print( "Proportion de o : ", nbO)
print( "Proportion de u : ", nbU)
