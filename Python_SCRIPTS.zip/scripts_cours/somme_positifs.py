# coding=utf8

somme = 0
n = int ( input ( "n ? " ) )
while n > 0 :
	somme = somme + n
	n = int ( input ( "n ? " ) )
print ( "Somme : %d" %(somme))
