l = [1, 1, 1, 2, 2, 3, 4, 4, 4, 5, 5, 1, 1, 1]

print(l, "--->")

i = 0
while (i < len(l)-1):
	if l[i] == l[i+1]:
		l.pop(i+1)
	else :
		i = i + 1

print(l)
