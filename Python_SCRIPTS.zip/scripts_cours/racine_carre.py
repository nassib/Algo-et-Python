# coding=utf8

import math
a = float ( input ( "a ? " ) )
if a >= 0 :
	r = math.sqrt ( a )
	print ( " La racine de %f est %f." %(a,r))
else :
	print ( " La valeur saisie ne peut pas être négative.")
print ( "Fin du programme." )
