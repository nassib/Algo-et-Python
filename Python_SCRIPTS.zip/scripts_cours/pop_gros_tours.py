# coding=utf8

k = int ( input ( "k ? " ))
p = 1
n = 0 # n est notre compteur
while p <= k :
	p = 2 * p
	n = n + 1
p = p / 2 # p > k, la valeur précédente est la bonne
n = n - 1
print ( "p : %d et n : %d" %(p,n))