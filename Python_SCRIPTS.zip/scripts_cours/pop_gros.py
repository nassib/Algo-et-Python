# coding=utf8

k = int ( input ( "k ? " ))
p = 1
while p <= k :
	p = 2 * p
p = p / 2 # p > k, la valeur précédente est la bonne
print ( "p : %d" %(p))