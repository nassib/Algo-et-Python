a = 5

def jolieFonction ():
	a = 10
	print ("jolieFonction --> a = ", a)


print ("Valeur initiale de a : ", a)
jolieFonction()
print ("Après la fonction a = ", a)
