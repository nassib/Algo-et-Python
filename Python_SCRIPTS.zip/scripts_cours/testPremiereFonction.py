def proportion ( chaine, caractere ) :
	"""Fréquence d'appartion du caractere dans la chaine.

	chaine est une chaine de caractère non vide
	caractere est un caractere unique"""

	n = len( chaine )
	k = chaine.count( caractere )

	return k/n

texte = "Bonjour à tous !"
nbO = proportion( texte, 'o')
nbU = proportion( texte, 'u')

print( "Texte : ", texte)
print( "Proportion de o : ", nbO)
print( "Proportion de u : ", nbU)

