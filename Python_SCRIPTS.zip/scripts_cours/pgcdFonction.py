print "Calcul de PGCD"

def pgcd(a, b):
	while a != b:
		if a > b: a = a - b
		else: b=b-a 
	return a

nombre1 = input ("Entrez un nombre : ")
nombre2 = input ("Entrez un second nombre : ")

c = pgcd (nombre1, nombre2)

print ("Le PGCD de %d et de %d est %d" %(nombre1, nombre2, c))
